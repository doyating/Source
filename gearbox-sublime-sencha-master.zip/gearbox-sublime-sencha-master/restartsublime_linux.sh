#!/bin/bash
killall -TERM -r "subl(ime(_text)?)?[0-9]?"
/usr/bin/subl