#!/bin/bash
killall -HUP 'Sublime Text'
# sleep 2
/Applications/Sublime\ Text.app/Contents/MacOS/Sublime\ Text