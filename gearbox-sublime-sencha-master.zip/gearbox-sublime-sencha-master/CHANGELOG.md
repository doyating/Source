1.0.0 - Jul 14, 2014

- Moved snippets into Sublime Text Plugin structure, based on RelatedFiles plugin
- Removed static paths
